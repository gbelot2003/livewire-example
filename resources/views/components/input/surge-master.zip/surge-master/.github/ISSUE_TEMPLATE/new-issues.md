---
name: New Issue
about: (Please don't open issues on this repo)
title: ''
labels: ''
assignees: ''

---

Note: Please do NOT submit issues on this repository.

All issues on this repository will be closed without explanation.

The only reason Issues are enabled on this repo is for internal note-taking purposes.

- Thanks!
